#include<stdio.h>
#include<time.h>
#include<math.h>
#include <string.h>
#include <stdlib.h>
typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef signed long long s64;
u32 D[32]={	 //Gamma * Alpha�� (Gamma * Alpha) x = Gamma Alpha(x) 
0x00000100,0x00000200,0x00000400,0x00000800,0x00001000,0x00002000,0x00004000,0x00008000,
0x00010000,0x00020000,0x00040000,0x00080000,0x00100000,0x00200000,0x00400000,0x00800000,
0x01000000,0x02000000,0x04000000,0x08000000,0x10000000,0x20000000,0x40000000,0x80000000,
0xe19fcf13,0x6b973726,0xd6876e4c,0x05a7dc98,0x0ae71199,0x1467229b,0x28ce449f,0x50358897};
u32 T[32]={ //�� Gamma * Alpha^-1�� (Gamma * Alpha^-1) x = Gamma Alpha^-1(x) 
0x180f40cd,0x301e8033,0x603ca966,0xc078fbcc,0x29f05f31,0x5249be62,0xa492d5c4,0xe18d0321,
0x00000001,0x00000002,0x00000004,0x00000008,0x00000010,0x00000020,0x00000040,0x00000080,
0x00000100,0x00000200,0x00000400,0x00000800,0x00001000,0x00002000,0x00004000,0x00008000,
0x00010000,0x00020000,0x00040000,0x00080000,0x00100000,0x00200000,0x00400000,0x00800000};
u32 D1[32]={ 
	0x03010102,0x06020204,0x0c040408,0x18080810,0x30101020,0x60202040,0xc0404080,0x9b80801b,
	0x01010203,0x02020406,0x0404080c,0x08081018,0x10102030,0x20204060,0x404080c0,0x80801b9b,
	0x01020301,0x02040602,0x04080c04,0x08101808,0x10203010,0x20406020,0x4080c040,0x801b9b80,
	0x02030101,0x04060202,0x080c0404,0x10180808,0x20301010,0x40602020,0x80c04040,0x1b9b8080};
u32 T1[32]={  
	0x0b0d090e,0x161a121c,0x2c342438,0x58684870,0xb0d090e0,0x7bbb3bdb,0xf66d76ad,0xf7daec41,
	0x0d090e0b,0x1a121c16,0x3424382c,0x68487058,0xd090e0b0,0xbb3bdb7b,0x6d76adf6,0xdaec41f7,
	0x090e0b0d,0x121c161a,0x24382c34,0x48705868,0x90e0b0d0,0x3bdb7bbb,0x76adf66d,0xec41f7da,
	0x0e0b0d09,0x1c161a12,0x382c3424,0x70586848,0xe0b0d090,0xdb7bbb3b,0xadf66d76,0x41f7daec};
u8 wt2[256]={
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,
0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0};
u8 SR_ni[256]={
0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d
};
void matrix_f(int t, int t1, int t2, int M_f[0x100][0x100][2][2]) //C[a][b] a=(t1,t2 -> t)��GF[2^8]^3,
{														// 2*2 b=(b3,b2,b1,b0) ��GF[2]^4��
	
	int i,j,k;
	FILE *fp;
	
	u64 e;
	int M[2][2][2]={0};
	for(i=0;i<2;i++) for(j=0;j<2;j++) for(k=0;k<2;k++) M[i][j][k] = 0;
	int C[2][2]={0};
	int c0,c1,x1,x2,x3,f,temp;
	 
	for(c0=0;c0<2;c0++)for(x1=0;x1<256;x1++)for(x2=0;x2<256;x2++)
	{	
		
		temp = x1+SR_ni[x2]+c0;
		c1 = (temp>>8);   
		f = wt2[(t & (temp)) ^ (t1&x1 ) ^ (t2&x2)];  
		M[f][c1][c0]++;
	}
	for(i=0;i<2;i++) for(j=0;j<2;j++) 
	{
		C[i][j] = M[0][i][j]-M[1][i][j];
		M_f[t][t2][i][j] = C[i][j];
	}
}
 
u8 location[0x100]={  
0,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3,
4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7};
u32 liehunhe_mask(u32 b,u32 liehunhe_Matrix[32])  
{	 
	u32 y,z;
	int i,k;

	z = 0;
	for(i=0;i<32;i++)
	{
		y = liehunhe_Matrix[i]&b;
		k = wt2[y&255] ^ wt2[(y>>8)&255] ^ wt2[(y>>16)&255] ^ wt2[(y>>24)&255];
		z ^= k<<i;
	}
	return z;
}
double Addition32_Input3(u32 a, u32 b, u32 c, u32 d, int &sign)  // (a,b,c)->d
{
	int M[16][3][3]= {{{4, 1, 0},{4, 6, 4},{0, 1, 4}},  
    {{2, 1, 0},{-2, 0, 2},{0, -1, -2}},  
    {{2, 1, 0},{-2, 0, 2},{0, -1, -2}}, 
    {{0, 1, 0},{0, -2, 0},{0, 1, 0}}, 
    {{2, 1, 0},{-2, 0, 2},{0, -1, -2}}, 
    {{0, 1, 0},{0, -2, 0},{0, 1, 0}},  
    {{0, 1, 0},{0, -2, 0},{0, 1, 0}}, 
    {{-2, 1, 0},{2, 0, -2},{0, -1, 2}},  
    {{-2, -1, 0},{2, 0, -2},{0, 1, 2}}, 
    {{0, -1, 0},{0, 2, 0},{0, -1, 0}},  
    {{0, -1, 0},{0, 2, 0},{0, -1, 0}},   
    {{2, -1, 0},{-2, 0, 2},{0, 1, -2}},  
    {{0, -1, 0},{0, 2, 0},{0, -1, 0}}, 
    {{2, -1, 0},{-2, 0, 2},{0, 1, -2}},  
    {{2, -1, 0},{-2, 0, 2},{0, 1, -2}}, 
    {{4, -1, 0},{4, -6, 4},{0, -1, 4}}};  
    
    int i,j,k;
    int flag8=0,flag4=0;
	int H[32]={0}; 
	s64 H2[3]={1,1,1}; 
	s64 temp[3]={0,0,0}; 
	
    for(i=0;i<32;i++) H[i] = (((d >> i) & 0x1) << 3) ^ (((a >> i) & 0x1) << 2) ^ (((b >> i) & 0x1) << 1) ^ ((c >> i) & 0x1);
	
	int sum=0;  
	
	for(i=31;i>=0;i--)
	{
		for(j=0;j<3;j++)
		{
			temp[j] = 0;
			for(k=0;k<3;k++)
			{
				temp[j] += H2[k] * M[H[i]][k][j];
				//printf("%d,%d,%d,\n",k,H2[k], M[H[i]][k][j]);
			} 
		}
		
		flag8 = 0; 
		for(j=0;j<3;j++)
		{
			if(temp[j] % 0x100 !=0)  
			{ 
				flag8 = 1;
				break;
			}
		}
		if(flag8 == 0) 
		{
			sum+=1;  
			for(j=0;j<3;j++) H2[j] = temp[j]/(1<<8);
			//printf("%d,    ",i); 
		}  
		else for(j=0;j<3;j++) H2[j] = temp[j];
		//printf("%d,%d, %I64d,%I64d,%I64d,\n",i,H[i], H2[0],H2[1],H2[2]); 
	} 
 	
 	if(H2[0] > 0) sign = 1;
 	else if(H2[0] < 0) 
	{
		H2[0] = -H2[0];
		//printf("%I64d,%I64d,\n",H2[0],abs(H2[0])); 
	 	sign = -1; 
	} 
 	else 
	{
		sign = 0; 
		return 4321;
	}
 	//printf("sum:%d,  %I64d,%I64d,\n",sum,H2[0],abs(H2[0])); 
 	
 	return (log(H2[0])/log(2)-96 + 8*sum);   
 
} 
void cor_f(u32 a, u32 b, int M_f[0x100][0x100][2][2], double &Temp_f, int &sign) // f(x,y) = x + Sbox^-1(y)  (a,b) ->a 
{
	s64 temp[4][4]={0};
	s64 p_f;
	u8 x[4],y[4];
	x[3] = a>>24; 			y[3] = b>>24;
	x[2] = (a>>16)&0xff; 	y[2] = (b>>16)&0xff;
	x[1] = (a>>8)&0xff;		y[1] = (b>>8)&0xff;
	x[0] = a&0xff; 			y[0] = b&0xff;
	
	temp[0][0] = M_f[x[3]][y[3]][0][0] + M_f[x[3]][y[3]][1][0];
	temp[0][1] = M_f[x[3]][y[3]][0][1] + M_f[x[3]][y[3]][1][1];
	
	temp[1][0] = temp[0][0] * M_f[x[2]][y[2]][0][0] + temp[0][1] * M_f[x[2]][y[2]][1][0];
	temp[1][1] = temp[0][0] * M_f[x[2]][y[2]][0][1] + temp[0][1] * M_f[x[2]][y[2]][1][1];
	
	temp[2][0] = temp[1][0] * M_f[x[1]][y[1]][0][0] + temp[1][1] * M_f[x[1]][y[1]][1][0];
	temp[2][1] = temp[1][0] * M_f[x[1]][y[1]][0][1] + temp[1][1] * M_f[x[1]][y[1]][1][1];
	
	p_f = temp[2][0] * M_f[x[0]][y[0]][0][0] + temp[2][1] * M_f[x[0]][y[0]][1][0];
	
	if(p_f == 0) {Temp_f = 4321; sign = 0;}
	
	if(p_f > 0)
	{
		Temp_f = log(p_f)/log(2) - 64;	sign = 1;
	}
	else if(p_f < 0) 
	{
		Temp_f = log(-p_f)/log(2) - 64;	sign = -1;
	}
}
int block_active_byte(u32 a)// 
{
	int i;
	for(i=3;i>=0;i--)
	{
		if(((a>>(8*i)) & 0xff) != 0)
			return i;	
	}	
} 
int block_active_bit(u32 a)// 
{
	int i;
	for(i=31;i>=0;i--)
	{
		if(((a>>i) & 0x1) != 0)
			return i;	
	}	
}
int main()
{ 
 
	
	double sum = 0,Temp_A3_1,Temp_A3_2,Temp_A3_3;
	double Temp_f1,Temp_f2,Temp_f3;
	int i,j,sign_f1,sign_f2,sign_f3,sign_A3_1,sign_A3_2,sign_A3_3;
	s64 d;
	u32 Gamma, Lambda, b, c;
	u32 Gamma_Alpha, Lambda_Alpha;
	u32 Gamma_Alpha_Inv, Lambda_Alpha_Inv;
	u32 Lambda_MT, Lambda_Alpha_MT, Lambda_Alpha_Inv_MT;
	
	FILE *fp;
	fp = fopen("the 24776 distinguishers of SNOW 2.0.txt","r");
	u32 text[24776]={0};
	for(i=0;i<24776;i++)
	{
		fscanf(fp,"%x\n",&text[i]);	
	} 
	fclose(fp);
	//printf("0x%08x,0x%08x,\n",text[0],text[24775]);
	
	int M_f[0x100][0x100][2][2]={0}; 
	for(i=0;i<0x100;i++) for(j=0;j<0x100;j++) matrix_f(i, i, j, M_f);
	 
	
	s64 Gammai,xuhuan;
	int Sum=0,test1,test2,min;
	double Max = -90,max;
	u32 Maxi = 0;
	
	
	for(Gammai = 0; Gammai < 24776; Gammai++)
	//for(Gammai = 0x00018001; Gammai < 0x00018002; Gammai++)
	{
		//if((Gammai % 0x10000000) == 0) printf("Gammai: 0x%08x, Sum:%d,\n",Gammai,Sum);
		
		Gamma = text[Gammai]; //text[Gammai]; 0x03000182 0x0c010001 0x0303600c
		
		//sum = 0;
		
		// cor_1
		Lambda_MT = liehunhe_mask(Gamma,D1); 	// M^T \bate 
		//printf("Lambda: 0x%08x, Lambda_MT: 0x%08x,\n",Lambda,Lambda_MT); 
		 
		
		cor_f(Gamma, Lambda_MT, M_f, Temp_f1, sign_f1); //-2^-12.911212 
			
		Temp_A3_1 = Addition32_Input3(Gamma, Gamma, Gamma, Gamma, sign_A3_1); //2^-1.584963 
		 	
		Gamma_Alpha = liehunhe_mask(Gamma,D);  
		
		Lambda_Alpha_MT = liehunhe_mask(Gamma_Alpha,D1); 	// M^T \bate 
		//printf("Lambda_Alpha: 0x%08x, Lambda_Alpha_MT: 0x%08x,\n",Lambda_Alpha,Lambda_Alpha_MT);
		 	
		cor_f(Gamma_Alpha, Lambda_Alpha_MT, M_f, Temp_f2, sign_f2); //2^-20.927740
		  
		/* */
		 
		Gamma_Alpha_Inv = liehunhe_mask(Gamma,T); 
		
		Lambda_Alpha_Inv_MT = liehunhe_mask(Gamma_Alpha_Inv,D1); 	// M^T \bate 
		//printf("Lambda_Alpha_Inv: 0x%08x, Lambda_Alpha_Inv_MT: 0x%08x,\n",Lambda_Alpha_Inv,Lambda_Alpha_Inv_MT);
		 
		
		cor_f(Gamma_Alpha_Inv, Lambda_Alpha_Inv_MT, M_f, Temp_f3, sign_f3); //-2^-23.509212 
		
		test1 = block_active_bit(Gamma_Alpha);
		test2 = block_active_bit(Gamma_Alpha_Inv);
		
		if(test1 > test2) min = test2;
		else min = test1;
		if(min == 31) xuhuan = 0x100000000;
		else xuhuan = 1 << min;
		
		sum = 0;
		printf("Gammai: %d, 0x%09I64x Maxi: 2^%f,\n", Gammai, xuhuan, Max);
		for(d=0;d<xuhuan;d++)
		{
			 
			
			Temp_A3_3 = Addition32_Input3(Gamma_Alpha_Inv, Gamma_Alpha_Inv ^ d, Gamma_Alpha_Inv, Gamma_Alpha_Inv, sign_A3_3);
			if(sign_A3_3 == 0) 
			{
				continue; 
			}
			
			Temp_A3_2 = Addition32_Input3(Gamma_Alpha ^ d, Gamma_Alpha, Gamma_Alpha, Gamma_Alpha, sign_A3_2);
			if(sign_A3_2 == 0) 
			{
				continue; 
			} 
			 
			sum += pow(2,Temp_A3_2 + Temp_A3_3 + 30) * sign_A3_2 * sign_A3_3; 
		}
		//printf("%d,%d, %d, 2^%f, %f, \n",sign_f2, sign_f3, sign_f1*sign_A3_1, (Temp_f1 + Temp_A3_1), 2*(Temp_f1 + Temp_A3_1)); 
		 
		if((sum * sign_f2 * sign_f3) > 0)
		{
			max = log(sum * sign_f2 * sign_f3)/log(2)-30 + 2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3;
			printf("cor_SNOW2: 2^%f, 0x%08x, 0x%08x, 0x%08x, \n", max, Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			printf("cor1: 2^%f, 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n",max-2*(Temp_f1 + Temp_A3_1) , (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			
			fp =fopen("The result.txt","a");
			fprintf(fp,"Gammai: %d, cor_SNOW2: 2^%f, 0x%08x, 0x%08x, 0x%08x, \n",Gammai, log(sum * sign_f2 * sign_f3)/log(2)-30 + 2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3, Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fprintf(fp,"cor1: 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n", (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fclose(fp); 
		} 
		else if((sum * sign_f2 * sign_f3) < 0)
		{
			max = log(-(sum * sign_f2 * sign_f3))/log(2)-30 + 2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3;
			printf("cor_SNOW2: -2^%f, 0x%08x, 0x%08x, 0x%08x, \n", max, Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			printf("cor1: 2^%f, 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n",max-2*(Temp_f1 + Temp_A3_1),  (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			
			fp =fopen("The result.txt","a");
			fprintf(fp,"Gammai: %d, cor_SNOW2: -2^%f, 0x%08x, 0x%08x, 0x%08x, \n",Gammai, log(-(sum * sign_f2 * sign_f3))/log(2)-30 + 2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3, Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fprintf(fp,"cor1: 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n", (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fclose(fp); 
		}
		else
		{
			printf("cor_SNOW2: 0, 0x%08x, 0x%08x, 0x%08x, \n", Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			printf("cor1: 2^%f, 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n",max-2*(Temp_f1 + Temp_A3_1),  (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			
			fp =fopen("The result.txt","a");
			fprintf(fp,"Gammai: %d, cor_SNOW2: 0, 0x%08x, 0x%08x, 0x%08x, \n",Gammai,  Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fprintf(fp,"cor1: 2^%f, 0x%08x, 0x%08x, 0x%08x, \n\n", (2*(Temp_f1 + Temp_A3_1) + Temp_f2 + Temp_f3), Gamma, Gamma_Alpha, Gamma_Alpha_Inv);
			fclose(fp); 
		}
	  	if(max > Max)
	  	{
	  		Max = max;
			Maxi = Gamma;	
		}
	} 
 
	return 0;	
} 
